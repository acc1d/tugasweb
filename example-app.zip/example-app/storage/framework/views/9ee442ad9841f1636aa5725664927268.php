<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Coba Laravel</title>
</head>

<body>
  <h1>Praktikum Web 2024</h1>
  <p>Nama : <?php echo e($nama); ?></p>
  <p>Nim : <?php echo e($nim); ?></p>
  <p>Email : <?php echo e($email); ?></p>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/coba.blade.php ENDPATH**/ ?>